// bazo ip
// const String apiUrl = 'http://192.168.100.252:5000/api';

// for localhost emulator
const String apiUrl = 'http://192.168.100.102:5000/api';
